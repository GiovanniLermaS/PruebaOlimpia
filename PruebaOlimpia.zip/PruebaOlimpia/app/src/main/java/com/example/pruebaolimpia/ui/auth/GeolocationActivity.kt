package com.example.pruebaolimpia.ui.auth

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.pruebaolimpia.R

class GeolocationActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_geolocation)
    }
}
